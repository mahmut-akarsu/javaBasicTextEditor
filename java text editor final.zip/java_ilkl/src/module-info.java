/**
 * 
 */
/**
 * @author Dell PC
 *
 */
module java_ilkl {
	requires java.desktop;
}