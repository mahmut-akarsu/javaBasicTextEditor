package java_ilkl;




public class Main{
	
	public static void main(String[] args){
		
			new TextEditor();
			
			
		
	
}
}

